<?php

class controller_me {

    public function __construct() {
        $_SESSION['module'] = 'me';
    }




    public function cart(){

    }

    public function me(){
      set_error_handler('ErrorHandler');
      try {
          $result1 = loadModel(MODEL_ME, 'me_model', 'getData', "hola");
      } catch (Exception $e) {
          $error_DB['success'] = false;
          $error_DB['error_type'] = 500;
          $error_DB['error_message'] = 'Hubo un problema en la Base de Datos, intentalo más tarde';
          echo json_encode($error_DB);
          exit;
      }
      restore_error_handler();

      echo json_encode($result1);
      exit;

    }



}
